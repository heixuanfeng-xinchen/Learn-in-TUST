#include "teacher.h"

Teacher::Teacher(QObject *parent) : QObject(parent)
{

}
