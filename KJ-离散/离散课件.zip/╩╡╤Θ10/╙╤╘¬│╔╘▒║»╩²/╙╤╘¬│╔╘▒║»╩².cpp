#include<iostream>
using namespace std;

class Circle
{
private:

public:
	void printXY(Coordinate &c);
};


class Coordinate
{
	friend void Circle::printXY(Coordinate &c);
public:
	Coordinate(int x,int y)
	{ 
		m_iX = x;
		m_iY = y;
	}
private:
	int m_iX;
	int m_iY;

	
};

void Circle::printXY(Coordinate &c)
{
	cout<<c.m_iX<<c.m_iY;
}


int main()	
{
	
    Coordinate coor(3,5);
    Circle cir;
    cir.printXY(coor);
	system("pause");
    return 0;
};

