#include<iostream>
using namespace std;

class Coordinate	
{
	friend void printXY(Coordinate &c);
   public:
	Coordinate(int x,int y)
	{ 
		m_iX = x;
		m_iY = y;
	}

   private:
	int m_iX;
	int m_iY;
};

void printXY(Coordinate &c)
{
   cout<<c.m_iX<<c.m_iY;
}

int main()	
{
    Coordinate coor(3,5);
    printXY(coor);
	system("pause");
    return 0;
}
